# Dashboard Datasource -  Native Plugin

This is a **built in** datasource that lets you reuse the query from other panels in the
same dashboard.