# Loki Data Source -  Native Plugin

This is a **built in** data source that allows you to connect to the Loki logging service.
