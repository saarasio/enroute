# Stackdriver Data Source - Native Plugin

Grafana ships with built-in support for Google Stackdriver. You just have to add it as a data source and you will be ready to build dashboards for your Stackdriver metrics.

Read more about it here:

[http://docs.grafana.org/datasources/stackdriver/](http://docs.grafana.org/datasources/stackdriver/)
