# Prometheus Data Source -  Native Plugin

Grafana ships with **built in** support for Prometheus, the open-source service monitoring system and time series database.

Read more about it here:

[http://docs.grafana.org/datasources/prometheus/](http://docs.grafana.org/datasources/prometheus/)
