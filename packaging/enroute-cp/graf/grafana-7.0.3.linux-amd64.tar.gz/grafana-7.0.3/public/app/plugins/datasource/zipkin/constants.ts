export const apiPrefix = '/api/v2';
